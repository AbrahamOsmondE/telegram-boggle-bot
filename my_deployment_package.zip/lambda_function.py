import pickle
import requests
import json
import os
import sys
import collections
import boto3

s3 = boto3.client('s3')
here = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.join(here, "./vendored"))

TOKEN = os.environ['TELEGRAM_TOKEN']
BASE_URL = "https://api.telegram.org/bot{}".format(TOKEN)


def findWords(board):
    WORD_KEY = '$'
    trie = pickle.loads(s3.get_object(Bucket="bogglebot", Key="trie.pkl")['Body'].read())

    rowNum = len(board)
    colNum = len(board[0])

    matchedWords = []
    dicti = collections.defaultdict(list)

    def backtracking(row, col, parent):

        letter = board[row][col]
        currNode = parent[letter]

        # check if we find a match of word
        word_match = currNode.pop(WORD_KEY, False)
        if word_match:
            # also we removed the matched word to avoid duplicates,
            #   as well as avoiding using set() for results.
            matchedWords.append(word_match)
            dicti[len(word_match)].append(word_match)

        # Before the EXPLORATION, mark the cell as visited
        board[row][col] = '#'

        # Explore the neighbors in 4 directions, i.e. up, right, down, left
        for (rowOffset, colOffset) in [(-1, 0), (0, 1), (1, 0), (0, -1), (1, 1), (-1, -1), (1, -1), (-1, 1)]:
            newRow, newCol = row + rowOffset, col + colOffset
            if newRow < 0 or newRow >= rowNum or newCol < 0 or newCol >= colNum:
                continue
            if not board[newRow][newCol] in currNode:
                continue
            backtracking(newRow, newCol, currNode)

        # End of EXPLORATION, we restore the cell
        board[row][col] = letter

        # Optimization: incrementally remove the matched leaf node in Trie.
        if not currNode:
            parent.pop(letter)

    for row in range(rowNum):
        for col in range(colNum):
            if board[row][col] in trie:
                backtracking(row, col, trie)

    string = ""
    for i in range(15, 2, -1):
        if dicti[i] == []:
            continue
        string += str(i) + " LETTERS" + "\n\n"
        string += "\n".join(dicti[i]) + "\n\n"
    return string


def lambda_handler(event, context):
    try:
        request_body = json.loads(event['body'])
        print(request_body)
        username = request_body['message']['from']['username']
        # request_body = event['body']
        # Extract the chat id from message
        chat_id = json.dumps(request_body['message']['chat']['id'])
        # chat_id = json.dumps(request_body['chat']['id'])
        # Extract the text from the message
        text = json.dumps(request_body['message']['text'])
        # text = json.dumps(request_body['message'])
        
        # allowed_usernames = ["abrahamosmond","fomosaurusrex","sxnyee","angdragon00","kkw1907","waxandwane","xanem1234","haloalicia","LucAV831"]
        # if username not in allowed_usernames:
        #     return
        letters = ''
        temp = text.replace('"','').split(" ")
        if len(temp) == 2:
            command, letters = temp
        else:
            command = temp[0]
            
        BOT_TOKEN = os.environ.get('TELEGRAM_TOKEN')
        # Updating the Bot Chat Id to be dynamic instead of static one earlier
        BOT_CHAT_ID = chat_id
        # Valid input command is /start or /help. however stripping the '/' here as it was having some conflict in execution.
        command = command[1:]
        if command == 'start':
            message = "Welcome! Please type /solve followed by a space and 16 letters\nExample:\n/solve abcdefghijklmnop\n\ngives a solution to the following board\n a b c d \n e f g h \n i j k l \n m n o p\n\nUse 'q' for the 'Qu' tile"
        elif command == 'help':
            message = "Please type /solve followed by a space and 16 letters\nExample:\n/solve abcdefghijklmnop\n\ngives a solution to the following board\n a b c d \n e f g h \n i j k l \n m n o p\n\nUse 'q' for the 'Qu' tile"
        elif command == 'solve':
            if letters.isalpha() and len(letters) == 16:
                letters = letters.upper()
                board = [list(letters[0:4]), list(letters[4:8]),
                    list(letters[8:12]), list(letters[12:17])]
                message = findWords(board)
            else:
                message = "Invalid input! Please type /solve followed by a space and 16 letters\nExample:\n/solve abcdefghijklmnop\n\ngives a solution to the following board\n a b c d \n e f g h \n i j k l \n m n o p\n\nUse 'q' for the 'Qu' tile"
        else:
            message = "I'm sorry, I didn't understand that command ({}). Please try again.".format(str(temp))
        
    
        send_text = 'https://api.telegram.org/bot' + BOT_TOKEN + '/sendMessage?chat_id=' + BOT_CHAT_ID + \
            '&parse_mode=HTML&text=' + message
        response = requests.get(send_text)
    
        return {
            'statusCode': 200,
            'body': json.dumps('Hello from Lambda!')
        }
    except Exception as e: 
        print(e)
        return

